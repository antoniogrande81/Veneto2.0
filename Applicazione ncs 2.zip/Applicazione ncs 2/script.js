// script.js

// Funzione per caricare il contenuto dal local storage
function uploadContent(sectionId) {
    const content = localStorage.getItem(sectionId);
    if (content) {
        document.getElementById(`${sectionId}-content`).value = content;
        alert('Contenuto caricato con successo!');
    } else {
        alert('Nessun contenuto trovato!');
    }
}

// Funzione per scaricare il contenuto nel local storage
function downloadContent(sectionId) {
    const content = document.getElementById(`${sectionId}-content`).value;
    localStorage.setItem(sectionId, content);
    alert('Contenuto salvato con successo!');
}

// Inizializzazione delle sezioni all'avvio della pagina
document.addEventListener('DOMContentLoaded', () => {
    uploadContent('blocco-note');
});
